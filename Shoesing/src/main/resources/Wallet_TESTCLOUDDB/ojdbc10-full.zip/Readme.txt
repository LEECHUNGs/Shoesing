======================================================
Oracle Free Use Terms and Conditions (FUTC) License 
======================================================
https://www.oracle.com/downloads/licenses/oracle-free-license.html
===================================================================

ojdbc10-full.tar.gz - JDBC Thin Driver and Companion JARS
========================================================
This TAR archive (ojdbc10-full.tar.gz) contains the 19.22.0.0 release of the Oracle JDBC Thin driver(ojdbc10.jar), the Universal Connection Pool (ucp.jar) and other companion JARs grouped by category. 

(1) ojdbc10.jar (4562755 bytes) - 
(SHA1 Checksum: 9a5f495a89653d2385a7e8436757dcde01794ebb)
Oracle JDBC Driver compatible with JDK8, JDK9, and JDK11;
(2) ucp.jar (1698546 bytes) - (SHA1 Checksum: 4ab95b249acd8eaa0abee6b7ed8d34edaa34c431)
Universal Connection Pool classes for use with JDK8, JDK9, and JDK11 -- for performance, scalability, high availability, sharded and multitenant databases.
(3) ojdbc.policy (11922 bytes) - Sample security policy file for Oracle Database JDBC drivers

======================
Security Related JARs
======================
Java applications require some additional jars to use Oracle Wallets. 
You need to use all the three jars while using Oracle Wallets. 

(4) oraclepki.jar (308163 bytes ) - (SHA1 Checksum: 711eb98455d7b619229426ef0f45385c1873b83f
Additional jar required to access Oracle Wallets from Java
(5) osdt_cert.jar (210391 bytes) - (SHA1 Checksum: fcbd0ea29c39708d9d345abcad5e0b1c590c5e97)
Additional jar required to access Oracle Wallets from Java
(6) osdt_core.jar (312562 bytes) - (SHA1 Checksum: 79b85ba995718fa2fc176047c3df2e4fc0a0ff63)
Additional jar required to access Oracle Wallets from Java

=============================
JARs for NLS and XDK support 
=============================
(7) orai18n.jar (1664182 bytes) - (SHA1 Checksum: 47cf95607afdcae43d920760a26f61229518c0d1) 
Classes for NLS support
(8) xdb.jar (129355 bytes) - (SHA1 Checksum: aa533bde4116cfb36d28934b7b38a7582a2177c1)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
(9) xmlparserv2.jar (1935724 bytes) - (SHA1 Checksum: a0b30bbde586b372913be10d82fdee7b752a026f)
Classes to support standard JDBC 4.x java.sql.SQLXML interface 
(10) xmlparserv2_sans_jaxp_services.jar (1933191 bytes) - (SHA1 Checksum: 509b59bf23aa32d1b35c953b224ddc8dc177cbae) 
Classes to support standard JDBC 4.x java.sql.SQLXML interface

====================================================
JARs for Real Application Clusters(RAC), ADG, or DG 
====================================================
(11) ons.jar (156646 bytes ) - (SHA1 Checksum: b2954320c7f546a1d43a9ec9c3a91b9140cd43a8)
for use by the pure Java client-side Oracle Notification Services (ONS) daemon
(12) simplefan.jar (32396 bytes) - (SHA1 Checksum: 3481ac4b38f133f68c282ff45907918b20b695bf)
Java APIs for subscribing to RAC events via ONS; simplefan policy and javadoc

==================================================================================
NOTE: The diagnosability JARs **SHOULD NOT** be used in the production environment. 
These JARs (ojdbc10_g.jar,ojdbc10dms.jar, ojdbc10dms_g.jar) are meant to be used in the 
development, testing, or pre-production environment to diagnose any JDBC related issues. 

=====================================
OJDBC - Diagnosability Related JARs
===================================== 

(13) ojdbc10_g.jar (7636525 bytes) - (SHA1 Checksum: 3684a44ffa1fa72ccad64e917f22a3cc23620e22)
Same as ojdbc10.jar except compiled with "javac -g" and contains tracing code.

(14) ojdbc10dms.jar (6347251 bytes) - (SHA1 Checksum: 5769c9099cae9b80a9c3a05ca0f7ebbd63259dcf)
Same as ojdbc10.jar, except that it contains instrumentation to support DMS and limited java.util.logging calls.

(15) ojdbc10dms_g.jar (7666297 bytes) - (SHA1 Checksum: 9b9d4396f19faea3a886a02d98114398767c3679)
Same as ojdbc10_g.jar except that it contains instrumentation to support DMS.

(16) dms.jar (2194533 bytes) - (SHA1 Checksum: cb20f6da4888d906ae44013dbec2cec0880d9941)
dms.jar required for DMS-enabled JAR files.

==================================================================
Oracle JDBC and UCP - Javadoc and README
==================================================================

(17) JDBC-Javadoc-19c.jar (2311993 bytes) - JDBC API Reference 19c

(18) ucp-Javadoc-19c.jar (366829 bytes) - UCP Java API Reference 19c

(19) simplefan-Javadoc-19c.jar (84161 bytes) - Simplefan API Reference 19c 

(20) xdb-Javadoc-19c.jar (2861664 bytes) - XDB API Reference 19c 

(21) xmlparserv2-Javadoc-19c.jar (2861664 bytes) - xmlparserv2 API Reference 19c 

(22) Jdbc-Readme.txt: It contains general information about the JDBC driver and bugs that have been fixed in the 19.22.0.0 release. 

(23) UCP-Readme.txt: It contains general information about UCP and bugs that are fixed in the 19.22.0.0 release. 


=================
USAGE GUIDELINES
=================
Refer to the JDBC Developers Guide (https://docs.oracle.com/en/database/oracle/oracle-database/19/jjdbc/index.html) and Universal Connection Pool Developers Guide (https://docs.oracle.com/en/database/oracle/oracle-database/19/jjucp/index.html) for more details.
